<?php
if(!isset($_SESSION)){
session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System </title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/main.css">
<link rel="stylesheet" href="../css/bootstrap.css">
</head>
<body>

<header>


  <div class="navbar bg-primary">
  <a href="index.php">Home</a>
  <a href="students.php">Students</a>
  <a href="teachers.php">Teachers</a>
  <a href="attendance.php">Attendance</a>
  <a href="report.php">Report</a>
  <a href="../logout.php">Logout</a>

</div>
<center>
    <h1 class="text-success">Online Attendance Management System </h1>
</center>
<div class="d-flex align-items-center">
<div class="mx-auto" role="status" aria-hidden="true">
  <p>Welcome <b><?=$_SESSION['tc_name']?></b> </p>
</div>

</header>