<?php
include('header.php');
?>
<?php

if(!isset($_SESSION['tc_id']))
{
  header('location: ../index.php');
}
?>

<center>

<div class="row">
    <div class="content">
      <p>One step solution for your class room :)</p>
    <img src="../img/tcr.png" height="200px" width="300px" />

  </div>

</div>

</center>

</body>
</html>
