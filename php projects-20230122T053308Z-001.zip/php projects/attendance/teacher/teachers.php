<?php
session_start();
include('header.php');
if(!isset($_SESSION['tc_id']))
{
  header('location: ../');
}
?>
<?php include('connect.php');?>


<center>

<div class=" container row">

  <div class="content">
    <h3>Teacher List</h3>
    
    <table class="table table=stripped c0l-9">
        <thead>  
          <tr>
            <th scope="col">Teacher ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
          </tr>
        </thead>

      <?php

        $i=0;
        $tcr_query = mysqli_query($con,"select * from teachers order by tc_id asc");
        while($tcr_data = mysqli_fetch_array($tcr_query)){
          $i++;

        ?>
          <tbody>
              <tr>
                <td><?php echo $tcr_data['tc_id']; ?></td>
                <td><?php echo $tcr_data['tc_name']; ?></td>
             
                <td><?php echo $tcr_data['tc_email']; ?></td>
        
              </tr>
          </tbody>

          <?php } ?>
          
    </table>

  </div>

</div>

</center>

</body>
</html>
