<?php
session_start();
include("header.php");

if(!isset($_SESSION['tc_id']))
{
  header('location: ../');
}
?>
<?php include('connect.php');?>

</head>
<body>

<header>



</div>

</header>

<center>

<div class="row">

  <div class="content">
    <h3>Individual Report</h3>

    <form method="post" action="">

    <label>Select Subject</label>
    <select name="whichcourse">
    <option  value="algo">Analysis of Algorithms</option>
         <option  value="algolab">Analysis of Algorithms Lab</option>
        <option  value="dbms">Database Management System</option>
        <option  value="dbmslab">Database Management System Lab</option>
        <option  value="weblab">Web Programming Lab</option>
        <option  value="os">Operating System</option>
        <option  value="oslab">Operating System Lab</option>
        <option  value="obm">Object Based Modeling</option>
        <option  value="softcomp">Soft Computing</option>
    </select>

      <p>  </p>
      <label>Student Reg. No.</label>
      <input type="text" name="st_id">
      <input type="submit" name="sr_btn" value="Go!" >

    </form>
<hr>
    <h3>Mass Report</h3>

    <form method="post" action="">

    <label>Select Subject</label>
    <select name="course">
    <option  value="algo">Analysis of Algorithms</option>
         <option  value="algolab">Analysis of Algorithms Lab</option>
        <option  value="dbms">Database Management System</option>
        <option  value="dbmslab">Database Management System Lab</option>
        <option  value="weblab">Web Programming Lab</option>
        <option  value="os">Operating System</option>
        <option  value="oslab">Operating System Lab</option>
        <option  value="obm">Object Based Modeling</option>
        <option  value="softcomp">Soft Computing</option>
    </select>
    <p>  </p>
      <label>Date ( yyyy-mm-dd )</label>
      <input type="text" name="date">
      <input type="submit" name="sr_date" value="Go!" >
    </form>

    <br>

    <br>

   <?php

    if(isset($_POST['sr_btn'])){

     $st_id = $_POST['st_id'];
     $course = $_POST['whichcourse'];
 $present = mysqli_query($con,"select count(*) from attendance where st_id='$st_id' and course = '$course' and at_status='Present'");
    $present=mysqli_fetch_assoc($present);
      $total_day= mysqli_query($con,"select count(*) from attendance where st_id='$st_id' and course = '$course'");
      $total_day=mysqli_fetch_assoc($total_day);
      ?>
      <div class="col-6">
      <table class="table table-striped table-responsive">
  <tbody>
      <tr>
          <td>Registration No.: </td>
          <td><?php echo $st_id; ?></td>
      </tr>

      <tr>
        <td>Total Class (Days): </td>
        <td><?php echo $total_day['count(*)'] ?> </td>
      </tr>

      <tr>
        <td>Present (Days): </td>
        <td><?php echo $present['count(*)'] ?> </td>
      </tr>

      <tr>
        <td>Absent (Days): </td>
        <td><?php echo $total_day['count(*)'] -  $present['count(*)'] ?> </td>
      </tr>

    </tbody>
    </table>
    </div>
    <?php
     } 

    if(isset($_POST['sr_date'])){

     $sdate = $_POST['date'];
     $course = $_POST['course'];

     $all_query = mysqli_query($con,"select * from attendance where at_date='$sdate' and course = '$course'");

    ?>
<div class="col-8">
    <table class="table table-stripped table-hover">
      <thead class="bg-primary">
        <tr>
          <th scope="col">Reg. No.</th>
          <th scope="col">Name</th>
          <th scope="col">Department</th>
          <th scope="col">Batch</th>
          <th scope="col">Date</th>
          <th scope="col">Attendance Status</th>
        </tr>
     </thead>


    <?php

     $i=0;
     while ($data = mysqli_fetch_array($all_query)) {

       $i++;

     ?>
        <tbody>
          <?php
          $ownperson=mysqli_fetch_array(mysqli_query($con,"select * from students where st_id='$data[st_id]'"));
?>
           <tr>
             <td><?php echo $data['st_id']; ?></td>
             <td><?php echo $ownperson['st_name']; ?></td>
             <td><?php echo $ownperson['st_dept']; ?></td>
             <td><?php echo $ownperson['st_batch']; ?></td>
             <td><?php echo $data['at_date']; ?></td>
             <td><?php echo $data['at_status']; ?></td>
           </tr>
        </tbody>

     <?php 
     }
  }
     ?>
     
</table>
</div>
  </form>

  </div>

</div>

</center>

</body>
</html>
