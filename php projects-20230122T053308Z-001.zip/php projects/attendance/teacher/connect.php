<?php
$con = new mysqli('localhost','root','','attsystem') or die('Cannot connect to server');


?>