<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System </title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<script src="css/bootstrap.js"></script>
</head>
<center>
  <h1 class="text-success col align-self-center">Online Attendance Management System </h1>
</center>
<!-- <body>
<header>

  <div class="navbar text-dark ">
  <a href="index.php">Home</a>
  <a href="students.php">Students</a>
  <a href="teachers.php">Faculties</a>
  <a href="attendance.php">Attendance</a>
  <a href="report.php">Report</a>
  <a href="../logout.php">Logout</a>
</div>
</header> -->
<?php include('connect.php');?>