<?php
include('header.php');
$error_msg='';
session_start();
if(isset($_POST['login']))
{
	//start of try block

	try{

		//checking empty fields
		if(empty($_POST['email'])){
			throw new Exception("email is required!");
			
		}
		if(empty($_POST['password'])){
			throw new Exception("Password is required!");
			
		}
		//establishing connection with db and things
		
		//checking login info into database
	
		if($_POST["type"] == 'teacher'){
			$row=0;

		$result=mysqli_query($con,"select * from teachers where tc_email='$_POST[email]' and tc_password='$_POST[password]'");

		$row=mysqli_num_rows(mysqli_query($con,"select * from teachers where tc_email='$_POST[email]' and tc_password='$_POST[password]'"));
if($row==1){
    $result=mysqli_fetch_array($result);
    $_SESSION['tc_name']=$result['tc_name'];
    $_SESSION['tc_id']=$result['tc_id'];
    $_SESSION['tc_email']=$result['tc_email'];
    header("location:teacher/index.php");
	

}else{
    $error_msg='Login Failed';
}
		}

		else if($_POST["type"] == 'student'){
			$row=0;

		$result=mysqli_query($con,"select * from students where st_email='$_POST[email]' and st_password='$_POST[password]'");

		$row=mysqli_num_rows(mysqli_query($con,"select * from students where st_email='$_POST[email]' and st_password='$_POST[password]'"));
if($row==1){
    $result=mysqli_fetch_array($result);
    $_SESSION['st_name']=$result['st_name'];
    $_SESSION['st_id']=$result['st_id'];
    $_SESSION['st_email']=$result['st_email'];
    header("location: student/index.php");

}
else{
    $error_msg='Login Failed';
}
        }
		else{
			throw new Exception("Username,Password or Role is wrong, try again!");
			
			header('location: login.php');
		}
	
    }
	//end of try block
	catch(Exception $e){
		$error_msg=$e->getMessage();
	}
	//end of try-catch
}

?>
<center>
<div class="container row">
<div class="col-3"></div>
<div class="col-6">
	<form class="form-control m-4 mb-2" method="post">
        <span><?=$error_msg?></span>
  <div class="row mb-3">
    <label for="inputEmail3" class="col-5 col-form-label">Email</label>
    <div class="col-7 ">
      <input type="email" class="form-control" id="inputEmail3" name="email">
    </div>
  </div>
  <div class="row mb-3">
    <label for="inputPassword3" class="col-5 col-form-label">Password</label>
    <div class="col-7">
      <input type="password" class="form-control" id="inputPassword3" name="password">
    </div>
  </div>
  <div class="form-group row " class="radio">
			<label for="input1" class="col-5 control-label">Role</label>
			<div class="col-7">
			  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="student" class="form-check" checked> Student
			  </label>
			  	  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="teacher" class="form-check"> Teacher
			  </label>
			</div>
			</div>
            			<input type="submit" class="btn btn-primary col-md-3 col-md-offset-7 m-4" value="Login" name="login" />
</form>
</div>
</div>
</div>
<div class="">
<br><br>
<p><strong>Have forgot your password? <a href="reset.php">Reset here.</a></strong></p>
<p><strong>If you don't have any account, <a href="signup.php">Signup</a> here</strong></p>
</div>
</center>
<!-- 
<body>
	<center>

<header>

  <h1>Online Attendance Management System 1.0</h1>

</header>

<h1>Login</h1>

<?php
//printing error message
if(isset($error_msg))
{
	echo $error_msg;
}
?>

<!-- Old Version -->
<!-- 
<form action="" method="post">
	
	<table>
		<tr>
			<td>Username </td>
			<td><input type="text" name="username"></input></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="password"></input></td>
		</tr>
		<tr>
			<td>Role</td>
			<td>
			<select name="type">
				<option name="teacher" value="teacher">Teacher</option>
				<option name="student" value="student">Student</option>
				<option name="admin" value="admin">Admin</option>
			</select>
			</td>
		</tr>
		<tr><td><br></td></tr>
		<tr>
			<td><button><input type="submit" name="login" value="Login"></input></button></td>
			<td><button><input type="reset" name="reset" value="Reset"></button></td>
		</tr>
	</table>
</form>
-->

<!-- <div class="content">
	<div class="row">

		<form method="post" class="form-horizontal col-6">
			<div class="form-group">
			    <label for="input1" class="col-sm-3 control-label">Username</label>
			    <div class="col-sm-7">
			      <input type="text" name="username"  class="form-control" id="input1" placeholder="your username" />
			    </div>
			</div>

			<div class="form-group">
			    <label for="input1" class="col-sm-3 control-label">Password</label>
			    <div class="col-sm-7">
			      <input type="password" name="password"  class="form-control" id="input1" placeholder="your password" />
			    </div>
			</div>


			


			<input type="submit" class="btn btn-primary col-md-3 col-md-offset-7" value="Login" name="login" />
		</form>
	</div>
</div>

 -->



<!--</center>
</body>
</html> -->