<div class="navbar bg-primary">
  <a href="index.php">Login</a>

</div>
<?php 
include("header.php");
  include('connect.php');


 ?>

</header>

<center>

<div class="content">
    <div class="row col-6">

    <form method="post" class="form-control ">
    <h3>Recover your password</h3>

      <div class="form-group">

          <label for="input1" class="col-sm-2 control-label">Email</label>
          <div class="col-sm-10">
            <input type="email" name="email"  class="form-control m-2" id="input1" placeholder="your email" />
          </div>
      </div>
      
  <div class="form-group row " class="radio">
			<label for="input1" class="col-sm-3 control-label">Role</label>
			<div class="col-sm-7">
			  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="student" checked> Student
			  </label>
			  	  <label>
			    <input type="radio" name="type" id="optionsRadios1" value="teacher"> Teacher
			  </label>
			</div>
			</div>
        

      <input type="submit" class="btn btn-primary col-md-2 col-md-offset-10 m-2 btn-sm" value="Go" name="reset" />
    </form>

      <br>

      <?php

          if(isset($_POST['reset'])){

          $test = $_POST['email'];
          $row = 0;
          $type=$_POST['type'];
          if($type=='student'){

          $query = mysqli_query($con,"select st_password from students where st_email = '$test'");
          $row = mysqli_num_rows($query);
          
          }
    else{
       $query = mysqli_query($con,"select tc_password from teachers where tc_email= '$test'");
          $row = mysqli_num_rows($query);
         
    }

          if($row == 0){
?>
      <div  class="content"><p>Email is not associated with any account. Contact OAMS 1.0</p></div>

<?php
          }

          else{
            if($type=='student'){
          $query=mysqli_fetch_array($query);
          $query=$query['st_password'];
            }
            else{
              $query=mysqli_fetch_array($query);
          $query=$query['tc_password'];
            }
?>
  <strong>
  <p style="text-align: left;">Hi there!<br>You requested for a password recovery. You may <a href="index.php">Login here</a> and enter this key as your password to login. Recovery key:<br><center><mark><?php echo $query;?></mark></center><br>Regards,Online Attendance Management System</p></strong>
<?php
      }
          }
  


       ?>

  </div>

</div>

</center>

</body>
</html>
