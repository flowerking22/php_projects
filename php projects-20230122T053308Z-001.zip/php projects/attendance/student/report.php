<?php
include('header.php');
if(!isset($_SESSION['st_id']))
{
  header('location: login.php');
}
?>
<!-- Menus ended -->

<center>

<!-- Content, Tables, Forms, Texts, Images started -->
<div class="row">

  <div class="content">
    <h3>Student Report</h3>
    <br>
    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">

  <div class="form-group">

    <label  for="input1" class="col-sm-3 control-label">Select Subject</label>
      <div class="col-sm-4 m-2">
      <select name="whichcourse" id="input1">
         <option  value="algo">Analysis of Algorithms</option>
         <option  value="algolab">Analysis of Algorithms Lab</option>
        <option  value="dbms">Database Management System</option>
        <option  value="dbmslab">Database Management System Lab</option>
        <option  value="weblab">Web Programming Lab</option>
        <option  value="os">Operating System</option>
        <option  value="oslab">Operating System Lab</option>
        <option  value="obm">Object Based Modeling</option>
        <option  value="softcomp">Soft Computing</option>

      </select>
      </div>

  </div>

        <div class="form-group m-4">
           <!-- <label for="input1" class="col-sm-3 control-label">Your Reg. No.</label> -->
              <div class="col-sm-7">
                  <input type="text" name="sr_id" hidden value="<?=$_SESSION['st_id']?>" class="form-control" id="input1" placeholder="enter your reg. no." />
              </div>
        </div>
        <input type="submit" class="btn btn-primary col-md-3 col-md-offset-7" value="Go!" name="sr_btn" />
    </form>

    <div class="content"><br></div>

    <form method="post" action="" class="form-horizontal col-md-6 col-md-offset-3">
    <table class="table table-striped table-responsive">
<?php
     
     //query for searching respective ID
    //  $all_query = mysql_query("select * from reports where reports.st_id='$sr_id' and reports.course = '$course'");
    //  $count_tot = mysql_num_rows($all_query);
   
    //  $singleT= mysqli_query($con,"select * from attendance where attendance.st_id='$sr_id' and attendance.course = '$course'");
 
  //    if ($row=mysqli_fetch_assoc($singleT))
  //    {
  //    $count_tot=$row[0];
  //    }

  //    while ($data = mysqli_fetch_array($all_query)) {
  //      $i++;
  //     //  if($data['st_status'] == "Present"){
  //     //     $count_pre++;
  //     //  }
  //      if($i <= 1){
  //    ?>
        
<!-- 
  //    <tbody>
  //     <tr>
  //         <td>Registration No.: </td>
  //         <td><?php echo $data['stat_id']; ?></td>
  //     </tr>

  //     <tr>
  //       <td>Total Class (Days): </td>
  //       <td><?php echo $count_tot; ?> </td>
  //     </tr>

  //     <tr>
  //       <td>Present (Days): </td>
  //       <td><?php echo $data[1]; ?> </td>
  //     </tr>

  //     <tr>
  //       <td>Absent (Days): </td>
  //       <td><?php echo $count_tot -  $data[1]; ?> </td>
  //     </tr>

  //   </tbody> -->
  
   <?php

    //checking the form for ID
    if(isset($_POST['sr_btn'])){

    //initializing ID 
     $sr_id = $_POST['sr_id'];
     $course = $_POST['whichcourse'];

     $i=0;
     $count_pre = 0;
    $present = mysqli_query($con,"select count(*) from attendance where st_id='$sr_id' and course = '$course' and at_status='Present'");
    $present=mysqli_fetch_assoc($present);
      $total_day= mysqli_query($con,"select count(*) from attendance where st_id='$sr_id' and course = '$course'");
      $total_day=mysqli_fetch_assoc($total_day);
      ?>
  <tbody>
      <tr class="bg-warning" >
          <td>Registration No.: </td>
          <td><?php echo $_SESSION['st_id']; ?></td>
      </tr>

      <tr>
        <td>Total Class (Days): </td>
        <td><?php echo $total_day['count(*)'] ?> </td>
      </tr>

      <tr>
        <td>Present (Days): </td>
        <td><?php echo $present['count(*)'] ?> </td>
      </tr>

      <tr>
        <td>Absent (Days): </td>
        <td><?php echo $total_day['count(*)'] -  $present['count(*)'] ?> </td>
      </tr>

    </tbody>
    <?php
    }
  ?>
    </table>
  </form>
  </div>

</div>
<!-- Contents, Tables, Forms, Images ended -->

</center>

</body>


</html>