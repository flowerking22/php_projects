<?php
if(!isset($_SESSION)){
session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Attendance Management System </title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/main.css">
<link rel="stylesheet" href="../css/bootstrap.css">
<script src="../css/bootstrap.js"></script>

</head>
<body>
<header>
  
  <div class="navbar bg-primary">
  <a href="index.php">Home</a>
  <a href="account.php">Account</a>
  <a href="report.php">Report</a>
  <a href="../logout.php">Logout</a>
   
</div>
<center>
<h1 class="text-success">Online Attendance Management System </h1> 
</center>

<div class="d-flex align-items-center">
<div class="mx-auto" role="status" aria-hidden="true">
  <p>Welcome <b><?=$_SESSION['st_name']?></b> </p>
</div>
  
</div>
</header>
<style>
  </style>
<?php
$con = new mysqli('localhost','root','','attsystem') or die('Cannot connect to server');
?>